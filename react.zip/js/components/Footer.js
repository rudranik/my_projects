import React from 'react';

function Footer() {
return (
<footer>
<p>&copy; 2025 My React App. All Rights Reserved.</p>
</footer>
);
}

export default Footer;