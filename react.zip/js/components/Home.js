import React from 'react';

function Home() {
return (
<main>
<h2>Hello, World!</h2>
<p>This is a basic React project setup.</p>
</main>
);
}

export default Home;
